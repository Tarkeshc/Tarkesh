$(function(){
				$('.mhn-slide').owlCarousel({
					nav:true,
					//loop:true,
					slideBy:'page',
					rewind:false,
					responsive:{
						0:{items:1},
						480:{items:2},
						600:{items:3},
						1000:{items:4}
					},
					smartSpeed:70,
					onInitialized:function(e){
						$(e.target).find('img').each(function(){
							if(this.complete){
								$(this).closest('.mhn-inner').find('.loader-circle').hide();
								$(this).closest('.mhn-inner').find('.mhn-img').css('background-image','url('+$(e.target).attr('src')+')');
							}else{
								$(this).bind('load',function(e){
									$(e.target).closest('.mhn-inner').find('.loader-circle').hide();
									$(e.target).closest('.mhn-inner').find('.mhn-img').css('background-image','url('+$(e.target).attr('src')+')');
								});
							}
						});
						$( ".owl-prev").html('<i class="fa fa-arrow-left"></i>');
				    	$( ".owl-next").html('<i class="fa fa-arrow-right"></i>');
					}
				});
			});
			var fixmeTop = $('.fixme').offset().top;
			$(window).scroll(function() {
			    var currentScroll = $(window).scrollTop();
			    if (currentScroll >= fixmeTop) {
			        $('.fixme').css({
			            position: 'fixed',
			            top: '0',
			            left: '0',
			            width:'100%',
			            zIndex:'1033',
			        });
			    } else {
			        $('.fixme').css({
			            position: 'static'
			        });
			    }
			});